package com.example.chhatarnivaas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
